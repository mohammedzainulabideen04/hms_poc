package com.cg.hms.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cg.hms.model.Reservations;
import com.cg.hms.repository.ReservationRepository;
import com.cg.hms.service.impl.ReservationServiceImpl;

@ExtendWith(MockitoExtension.class)
@RunWith(JUnitPlatform.class)
public class ReservationServiceImplTest {
	
	@InjectMocks
	private ReservationService reservationServiceImpl = new ReservationServiceImpl();
	
	@Mock
	private ReservationRepository resvRepo;
	
	
	@Test
	public void saveReservationTest(){

		Reservations reservation = new Reservations();
        reservation.setId(1);
        reservation.setRoomCode(123);
        reservation.setNumberOfChildren(2);
        reservation.setNumberOfAdults(2);
        reservation.setStatus(true);
        reservation.setNumberOfNights(3);
 
        when(resvRepo.save(any(Reservations.class))).thenReturn(new Reservations());
		int id = reservationServiceImpl.saveOrUpdate(reservation);
		assertThat(id);
	}

}
