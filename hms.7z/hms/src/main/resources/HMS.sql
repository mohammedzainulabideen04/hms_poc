DROP TABLE IF EXISTS Reservation;
CREATE TABLE Reservation  ( 
id INT AUTO_INCREMENT  PRIMARY KEY,
roomCode INT,
numberOfChildren INT,
numberOfAdults INT,
checkInDate date,
checkOutDate date,
status boolean,
numberOfNights INT
);

DROP TABLE IF EXISTS ROOMS;  
CREATE TABLE ROOMS(  
roomCode INT,  
name VARCHAR(50) NOT NULL, 
);  

DROP TABLE IF EXISTS Guest;
CREATE TABLE Guest  (
memberCode INT AUTO_INCREMENT  PRIMARY KEY,
phoneNumber INT,
company VARCHAR,
guestName VARCHAR,
eMail VARCHAR,
gender VARCHAR,
address VARCHAR
);

DROP TABLE IF EXISTS StaffMember;
CREATE TABLE StaffMember  (
    staffCode INT AUTO_INCREMENT  PRIMARY KEY,
    nic INT,
    salary INT,
    employeeName VARCHAR,
    occupation VARCHAR,
    eMail VARCHAR,
    age INT,
    address VARCHAR
);

INSERT INTO ROOMS VALUES (1, 'Andhra Pradesh');    
INSERT INTO ROOMS VALUES (2, 'Telangana');    
INSERT INTO ROOMS VALUES (3, 'Tamil Nadu');
INSERT INTO ROOMS VALUES (4, 'Kerala');
INSERT INTO ROOMS VALUES (5, 'Maharashtra');
INSERT INTO ROOMS VALUES (6, 'Karnataka');
INSERT INTO ROOMS VALUES (7, 'New Delhi');
INSERT INTO ROOMS VALUES (8, 'Uttar Pradesh');
