package com.cg.hms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.hms.model.Reservations;
import com.cg.hms.service.ReservationService;

@RestController
public class ReservationController {

	@Autowired
	ReservationService reservationService;

	@GetMapping("/hms/reservations")
	private List<Reservations> getReservationList()

	{
		return reservationService.getReservationList();

	}

	@GetMapping("/hms/getrRservations/{roomCode}")
	private Reservations getRoom(@PathVariable("roomCode") int roomCode)

	{
		return reservationService.getReservationById(roomCode);
	}

	@PostMapping("/hms/saveReservation")
	public ResponseEntity<String> saveRoom(@RequestBody Reservations resv) {
		int i = reservationService.saveOrUpdate(resv);
		return new ResponseEntity<String>("Registration has been done successfully with id:" + i, HttpStatus.CREATED);
	}
}
