package com.cg.hms.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hms.model.StaffMember;
import com.cg.hms.repository.StaffMemberRepository;
import com.cg.hms.service.StaffMemberService;

@Service
public class StaffMemberServiceImpl implements StaffMemberService {

	@Autowired
	StaffMemberRepository staffMemberRepository;
	
	/* To get all the staff Members */
	@Override
	public List<StaffMember> getStaffMembers() {
		List<StaffMember> staffmembers = new ArrayList<StaffMember>();
		staffMemberRepository.findAll().forEach(staffmember -> staffmembers.add(staffmember));
		return staffmembers;

	}
	
	/* To get all the staff Member by id */
	public StaffMember getStaffMember(int id) {
		return staffMemberRepository.findById(id).get();
	}

	/* To save staff member */
	public int saveStaff(StaffMember staffMember) {
		StaffMember s = (StaffMember) staffMemberRepository.save(staffMember);
		return s.getStaffCode();

	}

	/* To delete staff member */
	public void delete(int id) {
		staffMemberRepository.deleteById(id);
	}

	

}
