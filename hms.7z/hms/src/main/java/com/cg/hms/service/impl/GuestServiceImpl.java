package com.cg.hms.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hms.model.Guest;
import com.cg.hms.repository.GuestRepository;
import com.cg.hms.service.GuestService;

@Service
public class GuestServiceImpl implements GuestService {
	@Autowired
	GuestRepository guestRepository;

	@Override
	public int saveGuest(Guest member) {
		Guest g = guestRepository.save(member);
		return g.getMemberCode();
	}

	public Guest getGuestById(int id) {
		return guestRepository.findById(id).get();
	}

	public void delete(int id) {
		guestRepository.deleteById(id);
	}

	@Override
	public List<Guest> getAllGuests() {
		List<Guest> guests = new ArrayList<Guest>();
		guestRepository.findAll().forEach(guest -> guests.add(guest));
		return guests;
	}

}
