package com.cg.hms;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelManagementSystemApplication {
	private static final Logger LOGGER = LogManager.getLogger(HotelManagementSystemApplication.class);
	

	public static void main(String[] args) {
		SpringApplication.run(HotelManagementSystemApplication.class, args);
		
		try {
			LOGGER.info("Welocome to Hotel Management System   ~~~"+InetAddress.getLocalHost().getHostName());
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        LOGGER.debug("Debug level log message");
        LOGGER.error("Error level log message");
	}

}
