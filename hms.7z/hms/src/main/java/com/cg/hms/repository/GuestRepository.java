package com.cg.hms.repository;

import org.springframework.data.repository.CrudRepository;

import com.cg.hms.model.Guest;

public interface GuestRepository extends CrudRepository<Guest, Integer> {

}
