package com.cg.hms.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hms.model.Reservations;
import com.cg.hms.repository.ReservationRepository;
import com.cg.hms.service.ReservationService;

@Service
public class ReservationServiceImpl implements ReservationService {

	@Autowired
	ReservationRepository reservationRepository;

	public List<Reservations> getReservationList() {

		List<Reservations> reserv = new ArrayList<Reservations>();
		reservationRepository.findAll().forEach(r -> reserv.add(r));
		return reserv;

	}

	public Reservations getReservationById(int id) {

		return reservationRepository.findById(id).get();

	}

	public int saveOrUpdate(Reservations room) {
		Reservations r = (Reservations) reservationRepository.save(room);
		return r.getId();
	}

}
