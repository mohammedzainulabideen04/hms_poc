package com.cg.hms.repository;

import org.springframework.data.repository.CrudRepository;

import com.cg.hms.model.Reservations;

public interface ReservationRepository extends CrudRepository<Reservations, Integer>
{
	

}
