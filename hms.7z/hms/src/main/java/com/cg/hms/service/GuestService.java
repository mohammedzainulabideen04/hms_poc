package com.cg.hms.service;

import java.util.List;

import com.cg.hms.model.Guest;

public interface GuestService {
	
	public int saveGuest(Guest member);

	public List<Guest> getAllGuests();

	public Guest getGuestById(int id);


	public void delete(int id);
}
