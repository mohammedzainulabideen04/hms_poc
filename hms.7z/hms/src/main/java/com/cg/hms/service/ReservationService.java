package com.cg.hms.service;

import java.util.List;

import com.cg.hms.model.Reservations;

public interface ReservationService {

	public List<Reservations> getReservationList();

	public Reservations getReservationById(int id);

	public int saveOrUpdate(Reservations reserv);

}
