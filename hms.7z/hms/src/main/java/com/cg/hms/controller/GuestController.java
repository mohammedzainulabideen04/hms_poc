package com.cg.hms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.hms.model.Guest;
import com.cg.hms.service.GuestService;

@RestController
public class GuestController {

	@Autowired
	GuestService guestService;

	@GetMapping("/guest")
	private List<Guest> getAllGuest() {
		return guestService.getAllGuests();
	}

	@GetMapping("/guest/{id}")
	private Guest getGuest(@PathVariable("id") int id) {
		return guestService.getGuestById(id);
	}

	@DeleteMapping("/guest/{id}")
	private void deleteGuest(@PathVariable("id") int id) {
		guestService.delete(id);
	}

	@PostMapping("/saveGuest")
	private int saveGuest(@RequestBody Guest guest) {
		guestService.saveGuest(guest);
		return guest.getMemberCode();
	}
}
