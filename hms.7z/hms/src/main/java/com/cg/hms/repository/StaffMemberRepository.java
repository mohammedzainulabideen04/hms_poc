package com.cg.hms.repository;

import org.springframework.data.repository.CrudRepository;

import com.cg.hms.model.StaffMember;

public interface StaffMemberRepository extends CrudRepository<StaffMember, Integer> {

}
