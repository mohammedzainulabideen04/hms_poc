package com.cg.hms.service;

import java.util.List;

import com.cg.hms.model.StaffMember;

public interface StaffMemberService {
	public List<StaffMember> getStaffMembers();

	public StaffMember getStaffMember(int id);

	public int saveStaff(StaffMember member);

	public void delete(int id);

}
