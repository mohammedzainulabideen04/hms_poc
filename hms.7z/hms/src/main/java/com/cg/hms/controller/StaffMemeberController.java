package com.cg.hms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.hms.model.StaffMember;
import com.cg.hms.service.StaffMemberService;

@RestController
public class StaffMemeberController {

	@Autowired
	StaffMemberService staffingService;

	@GetMapping("/staffMember")
	private List<StaffMember> getStaffMembers() {
		return staffingService.getStaffMembers();
	}

	@GetMapping("/staffMember/{id}")
	private StaffMember getStaffMember(@PathVariable("id") int id) {
		return staffingService.getStaffMember(id);
	}

	@DeleteMapping("/staffMember/{id}")
	private void deleteStaffMember(@PathVariable("id") int id) {
		staffingService.delete(id);

	}

	@PostMapping("/staffMember")
	private int saveStaffMember(@RequestBody StaffMember staff) {
		staffingService.saveStaff(staff);
		return staff.getStaffCode();
	}
}
