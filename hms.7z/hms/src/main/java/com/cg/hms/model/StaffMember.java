package com.cg.hms.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class StaffMember {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int staffCode;

	@Column
	private int nic;

	@Column
	private int salary;

	@Column
	private String employeeName;

	@Column
	private String occupation;

	@Column
	private String eMail;

	@Column
	private int age;

	@Column
	private String address;

	public int getStaffCode() {
		return staffCode;
	}

	public void setStaffCode(int staffCode) {
		this.staffCode = staffCode;
	}

	public int getNic() {
		return nic;
	}

	public void setNic(int nic) {
		this.nic = nic;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String geteMail() {
		return eMail;
	}

	public void seteMail(String eMail) {
		this.eMail = eMail;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}
